<?php
// a=index&m=home
define('ROOTPATH', dirname(__FILE__));
$dir = opendir(ROOTPATH . '/common');
while($file = readdir($dir))
{
	if($file != '.' && $file != '..' && !is_dir($file))
	{
		require_once(ROOTPATH . '/common/' . $file);
	}
}
require_once(ROOTPATH.'/controller/action.class.php');
$a = (isset($_GET['a']) && !empty($_GET['a'])) ? slash($_GET['a']) : 'index'; 
$m = (isset($_GET['m']) && !empty($_GET['m'])) ? slash($_GET['m']) : 'home'; 
$action = new $m();
$result = $action->$a();
?>