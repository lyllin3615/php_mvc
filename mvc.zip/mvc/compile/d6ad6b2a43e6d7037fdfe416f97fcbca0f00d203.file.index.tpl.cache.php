<?php /* Smarty version Smarty-3.1.6, created on 2015-03-20 00:36:38
         compiled from "G:\phpweb\apache2\htdocs\mvc/template\index\index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:21973550aef00387904-33271031%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd6ad6b2a43e6d7037fdfe416f97fcbca0f00d203' => 
    array (
      0 => 'G:\\phpweb\\apache2\\htdocs\\mvc/template\\index\\index.tpl',
      1 => 1426782996,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '21973550aef00387904-33271031',
  'function' => 
  array (
  ),
  'cache_lifetime' => 10,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_550aef003ed22',
  'variables' => 
  array (
    'name' => 0,
    'res' => 0,
    'res1' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_550aef003ed22')) {function content_550aef003ed22($_smarty_tpl) {?><?php echo $_smarty_tpl->tpl_vars['name']->value;?>

<?php echo print_r($_smarty_tpl->tpl_vars['res']->value);?>


<?php echo print_r($_smarty_tpl->tpl_vars['res1']->value);?>
<?php }} ?>