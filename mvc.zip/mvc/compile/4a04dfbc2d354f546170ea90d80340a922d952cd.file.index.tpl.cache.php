<?php /* Smarty version Smarty-3.1.6, created on 2015-03-20 09:22:11
         compiled from "F:\phpweb\apache\htdocs\mvc/template\index\index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:28097550b7405d61994-09140667%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4a04dfbc2d354f546170ea90d80340a922d952cd' => 
    array (
      0 => 'F:\\phpweb\\apache\\htdocs\\mvc/template\\index\\index.tpl',
      1 => 1426814528,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '28097550b7405d61994-09140667',
  'function' => 
  array (
  ),
  'cache_lifetime' => 1000,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_550b7405db1b4',
  'variables' => 
  array (
    'name' => 0,
    'res' => 0,
    'res1' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_550b7405db1b4')) {function content_550b7405db1b4($_smarty_tpl) {?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<title>test</title>
</head>
<body>

<?php echo $_smarty_tpl->tpl_vars['name']->value;?>

<?php echo print_r($_smarty_tpl->tpl_vars['res']->value);?>


<?php echo print_r($_smarty_tpl->tpl_vars['res1']->value);?>

</body>
</html><?php }} ?>