<?php /* Smarty version Smarty-3.1.6, created on 2015-03-19 23:43:34
         compiled from "G:\phpweb\apache2\htdocs\mvc/template\index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2700550aee3a886342-31154036%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f9fcf0f16fcf590ad531829f79d3c62843ccbb85' => 
    array (
      0 => 'G:\\phpweb\\apache2\\htdocs\\mvc/template\\index.tpl',
      1 => 1426779786,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2700550aee3a886342-31154036',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_550aee3a9ab31',
  'variables' => 
  array (
    'name' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_550aee3a9ab31')) {function content_550aee3a9ab31($_smarty_tpl) {?><?php echo $_smarty_tpl->tpl_vars['name']->value;?>
<?php }} ?>