<?php /* Smarty version Smarty-3.1.6, created on 2014-11-08 11:17:46
         compiled from "./template\index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:23103545d8b5ab43341-76687909%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '38e07ff642b0b9723286db0d256fede0025ef109' => 
    array (
      0 => './template\\index.tpl',
      1 => 1415416252,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '23103545d8b5ab43341-76687909',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'name' => 0,
    'arr' => 0,
    'v' => 0,
    'vv' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_545d8b5abeb2f',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_545d8b5abeb2f')) {function content_545d8b5abeb2f($_smarty_tpl) {?><?php echo $_smarty_tpl->tpl_vars['name']->value;?>

<?php if ($_smarty_tpl->tpl_vars['name']->value=='linyuan'){?>
yes
<?php }else{ ?>
no
<?php }?>
<br />
<?php  $_smarty_tpl->tpl_vars['v'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['v']->_loop = false;
 $_smarty_tpl->tpl_vars['k'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['arr']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['v']->key => $_smarty_tpl->tpl_vars['v']->value){
$_smarty_tpl->tpl_vars['v']->_loop = true;
 $_smarty_tpl->tpl_vars['k']->value = $_smarty_tpl->tpl_vars['v']->key;
?>
  <?php  $_smarty_tpl->tpl_vars['vv'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['vv']->_loop = false;
 $_smarty_tpl->tpl_vars['kk'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['v']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['vv']->key => $_smarty_tpl->tpl_vars['vv']->value){
$_smarty_tpl->tpl_vars['vv']->_loop = true;
 $_smarty_tpl->tpl_vars['kk']->value = $_smarty_tpl->tpl_vars['vv']->key;
?>
  <?php echo $_smarty_tpl->tpl_vars['vv']->value;?>
<br />
  <?php } ?>
<?php } ?><?php }} ?>