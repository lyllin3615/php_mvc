<?php
if(!defined('ROOTPATH')) exit('error!');
class model
{
	static $link = null;
	function __construct()
	{
		require_once(ROOTPATH.'/model/Db/ez_sql_core.php');
		require_once(ROOTPATH.'/model/Db/ez_sql_mysql.php');
		if(is_null(self::$link))
		{
			self::$link  = new ezSQL_mysql(DB_USER,DB_PASSWORD,DB_NAME,DB_HOST);
		}
		return self::$link;
	}
}
?>