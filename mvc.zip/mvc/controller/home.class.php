<?php
if(!defined('ROOTPATH')) exit('error!');
class home extends action
{
	public function index()
	{
		echo '����home.class.php�е�index����';
	}

	public function test()
	{
		if(!$this->smarty->isCached('index/index.tpl'))
		{
			$res = self::$db->ok();
			$res1 = self::$db->yes();
			$this->smarty->assign('res', $res);
			$this->smarty->assign('res1', $res1);
			$this->smarty->assign('name', 'the time is :' . date('Y-m-d H:i:s', time()));
		}
		$this->smarty->display('index/index.tpl');
	}
}
?>