<?php
if(!defined('ROOTPATH')) exit('error!');
//����
class action
{
	static $db = null;
	public $smarty = null;
	function __construct()
	{
		// ����model
		global $m;
		//���� view
		require_once(ROOTPATH.'/libs/Smarty.class.php');
		$smarty = new Smarty;
		$smarty->template_dir = ROOTPATH.'/template/';
		$smarty->compile_dir = ROOTPATH.'/compile/';
		$smarty->config_dir = ROOTPATH.'/config/';
		$smarty->cache_dir = ROOTPATH.'/cache/';
		$smarty->debugging = false;
		$smarty->caching = true;
		$smarty->cache_lifetime = 10;
		$this->smarty = $smarty;
		require_once(ROOTPATH . '/model/model.class.php');
		require_once(ROOTPATH . '/model/'.$m.'Model.class.php');
		$model = $m.'Model';
		self::$db = new $model();

	}	
}
?>