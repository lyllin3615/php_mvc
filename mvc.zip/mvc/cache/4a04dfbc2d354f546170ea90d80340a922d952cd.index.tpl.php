<?php /*%%SmartyHeaderCode:28097550b7405d61994-09140667%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4a04dfbc2d354f546170ea90d80340a922d952cd' => 
    array (
      0 => 'F:\\phpweb\\apache\\htdocs\\mvc/template\\index\\index.tpl',
      1 => 1426814528,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '28097550b7405d61994-09140667',
  'cache_lifetime' => 10,
  'version' => 'Smarty-3.1.6',
  'unifunc' => 'content_550b7adf07de2',
  'has_nocache_code' => false,
),true); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_550b7adf07de2')) {function content_550b7adf07de2($_smarty_tpl) {?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html lang="zh-cn">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<title>test</title>
</head>
<body>

the time is :2015-03-20 09:41:51
Array
(
    [0] => Array
        (
            [id] => 1
            [name] => 0000xxfdsfsf
            [time] => 4
        )

    [1] => Array
        (
            [id] => 2
            [name] => 深圳
            [time] => 3
        )

    [2] => Array
        (
            [id] => 4
            [name] => 广州
            [time] => 3
        )

    [3] => Array
        (
            [id] => 12
            [name] => 987654@qq.comlin3615
            [time] => 3
        )

    [4] => Array
        (
            [id] => 3
            [name] => 梧放
            [time] => 2
        )

    [5] => Array
        (
            [id] => 6
            [name] => abc'sfsf;afsd:dsaf",./<>?\=-0987654321`~!@#$%^&*()_+|
            [time] => 3
        )

    [6] => Array
        (
            [id] => 7
            [name] => sdfasd
            [time] => 3
        )

    [7] => Array
        (
            [id] => 9
            [name] => 0000xxfdsfsf
            [time] => 4
        )

)
1

Array
(
    [0] => Array
        (
            [id] => 1
            [fid] => 0
            [name] => 电子
        )

    [1] => Array
        (
            [id] => 2
            [fid] => 1
            [name] => 数码
        )

    [2] => Array
        (
            [id] => 3
            [fid] => 2
            [name] => 相机
        )

    [3] => Array
        (
            [id] => 4
            [fid] => 1
            [name] => 3C
        )

    [4] => Array
        (
            [id] => 5
            [fid] => 4
            [name] => 笔记本
        )

    [5] => Array
        (
            [id] => 6
            [fid] => 0
            [name] => 服装
        )

    [6] => Array
        (
            [id] => 7
            [fid] => 6
            [name] => 女装
        )

    [7] => Array
        (
            [id] => 8
            [fid] => 7
            [name] => 裤子
        )

    [8] => Array
        (
            [id] => 9
            [fid] => 6
            [name] => 男装
        )

    [9] => Array
        (
            [id] => 10
            [fid] => 9
            [name] => 西装
        )

    [10] => Array
        (
            [id] => 11
            [fid] => 2
            [name] => 手机
        )

    [11] => Array
        (
            [id] => 12
            [fid] => 4
            [name] => 平板
        )

    [12] => Array
        (
            [id] => 13
            [fid] => 7
            [name] => 裙子
        )

    [13] => Array
        (
            [id] => 14
            [fid] => 9
            [name] => 皮革
        )

)
1
</body>
</html><?php }} ?>